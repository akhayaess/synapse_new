# synapse-dataplatform
A modern data platform implemented on Azure Synapse Analytics using ELT Framework - https://github.com/bennyaustin/elt-framework with resuable artifacts. 
Data platform infrastructure  provisioned using https://github.com/bennyaustin/iac-synapse-dataplatform
